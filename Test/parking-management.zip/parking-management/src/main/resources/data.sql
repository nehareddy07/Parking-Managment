insert into app_user values(1,'John','david','OW1232','gaeyaneha@gmail.com','12WE3242','text')
insert into app_user values(2,'John1','gaeyaneha@gmail.com','OW1232','david1','12WE3243','test')

--insert into entry values(2,'area1',90,'2020-08-01 10:20:00.000',800,3,'2020-08-01 10:20:00.000','2020-08-01 10:20:00.000')